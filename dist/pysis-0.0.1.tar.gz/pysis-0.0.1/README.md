my_package/
|-- my_module.py
|-- __init__.py
|-- setup.py
|-- README.md
|-- LICENSE
